# NEWS-BLOG
A simple grid css interface that structure news
and other articles in a unique way, attractive to
the users eye
